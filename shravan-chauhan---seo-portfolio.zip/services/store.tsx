
import React, { createContext, useContext, useState, ReactNode } from 'react';
import { CaseStudy, BlogPost, Lead, AppSettings, SystemLog } from '../types';
import { INITIAL_CASE_STUDIES, INITIAL_BLOG_POSTS, DEFAULT_SETTINGS } from '../constants';
import emailjs from '@emailjs/browser';

interface StoreContextType {
  caseStudies: CaseStudy[];
  blogPosts: BlogPost[];
  leads: Lead[];
  settings: AppSettings;
  logs: SystemLog[];
  addCaseStudy: (study: CaseStudy) => void;
  addBlogPost: (post: BlogPost) => void;
  deleteCaseStudy: (id: string) => void;
  deleteBlogPost: (id: string) => void;
  addLead: (lead: Omit<Lead, 'id' | 'submittedAt' | 'status'>) => Promise<boolean>;
  updateLeadStatus: (id: string, status: Lead['status']) => void;
  updateSettings: (newSettings: AppSettings) => void;
  testSystem: () => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [caseStudies, setCaseStudies] = useState<CaseStudy[]>(INITIAL_CASE_STUDIES);
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>(INITIAL_BLOG_POSTS);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [logs, setLogs] = useState<SystemLog[]>([]);

  const addLog = (type: SystemLog['type'], status: SystemLog['status'], message: string) => {
    const newLog: SystemLog = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toLocaleTimeString(),
      type,
      status,
      message
    };
    setLogs(prev => [newLog, ...prev]);
  };

  const addCaseStudy = (study: CaseStudy) => {
    setCaseStudies((prev) => [study, ...prev]);
    addLog('System', 'Success', `Added case study: ${study.title}`);
  };

  const addBlogPost = (post: BlogPost) => {
    setBlogPosts((prev) => [post, ...prev]);
    addLog('System', 'Success', `Added blog post: ${post.title}`);
  };

  const deleteCaseStudy = (id: string) => {
    setCaseStudies((prev) => prev.filter((s) => s.id !== id));
    addLog('System', 'Success', `Deleted case study ID: ${id}`);
  };

  const deleteBlogPost = (id: string) => {
    setBlogPosts((prev) => prev.filter((p) => p.id !== id));
    addLog('System', 'Success', `Deleted blog post ID: ${id}`);
  };

  const addLead = async (leadData: Omit<Lead, 'id' | 'submittedAt' | 'status'>): Promise<boolean> => {
    const newLead: Lead = {
      ...leadData,
      id: Math.random().toString(36).substr(2, 9),
      submittedAt: new Date().toLocaleString(),
      status: 'New'
    };
    
    setLeads(prev => [newLead, ...prev]);
    addLog('CRM', 'Success', `New lead captured: ${newLead.name}`);

    // --- Email Sending Logic ---
    await new Promise(resolve => setTimeout(resolve, 500)); // Small artificial delay for UX

    if (settings.testMode) {
      console.log(`[TEST MODE] Sending Email to ${settings.notificationEmail}: New Lead from ${newLead.name}`);
      console.log(`[TEST MODE] Content: ${newLead.message}`);
      addLog('Email', 'Success', `[TEST] Notification simulated to ${settings.notificationEmail}`);
      addLog('Email', 'Success', `[TEST] Auto-reply simulated to ${newLead.email}`);
    } else {
      // 1. Try EmailJS (Client Side)
      if (settings.enableEmailJs && settings.emailJsPublicKey && settings.emailJsServiceId && settings.emailJsTemplateId) {
         try {
            await emailjs.send(
              settings.emailJsServiceId,
              settings.emailJsTemplateId,
              {
                from_name: newLead.name,
                from_email: newLead.email,
                message: newLead.message,
                phone: newLead.phone || '',
                website: newLead.website || '',
                preferred_time: newLead.preferredTime || '',
                to_email: settings.notificationEmail
              },
              settings.emailJsPublicKey
            );
            addLog('Email', 'Success', `Sent via EmailJS to ${settings.notificationEmail}`);
         } catch (error: any) {
            console.error('EmailJS Error:', error);
            addLog('Email', 'Failed', `EmailJS Error: ${error?.text || 'Unknown error'}`);
         }
      } else {
        // 2. Fallback / No Config
        addLog('Email', 'Failed', 'No Email Service Configured (EmailJS disabled or missing keys). Enable EmailJS in Admin > Settings.');
      }
    }

    // --- SMS Sending Logic ---
    if (settings.enableTwilio) {
      if (settings.testMode) {
        console.log(`[TEST MODE] SMS to ${settings.notificationPhone}: New lead from ${newLead.name}`);
        addLog('SMS', 'Success', `[TEST] SMS simulated to ${settings.notificationPhone}`);
      } else {
        // Real SMS logic would go here (requires backend)
        addLog('SMS', 'Failed', 'Twilio requires backend API (Client-side SMS not supported securely)');
      }
    }

    return true;
  };

  const updateLeadStatus = (id: string, status: Lead['status']) => {
    setLeads(prev => prev.map(l => l.id === id ? { ...l, status } : l));
    addLog('CRM', 'Success', `Lead status updated to ${status}`);
  };

  const updateSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    addLog('System', 'Success', 'Settings updated');
  };

  const testSystem = () => {
    addLead({
      name: 'Test User',
      email: 'test@example.com',
      message: 'This is a test lead to verify system integrations.',
      phone: '123-456-7890',
      consent: true,
      source: 'Admin Test'
    });
  };

  return (
    <StoreContext.Provider value={{ 
      caseStudies, 
      blogPosts, 
      leads, 
      settings, 
      logs,
      addCaseStudy, 
      addBlogPost, 
      deleteCaseStudy, 
      deleteBlogPost,
      addLead,
      updateLeadStatus,
      updateSettings,
      testSystem
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (context === undefined) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};