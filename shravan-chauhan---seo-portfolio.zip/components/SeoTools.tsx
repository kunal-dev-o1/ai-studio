import React, { useState, useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { Search, Network, CheckCircle, FileText, AlertTriangle, Cpu, Zap, BarChart } from 'lucide-react';

export const KeywordClusterTool = () => {
  const [input, setInput] = useState('');
  const [clusters, setClusters] = useState<{ topic: string, keywords: string[] }[]>([]);
  const [loading, setLoading] = useState(false);

  const handleCluster = () => {
    if (!input) return;
    setLoading(true);
    setTimeout(() => {
      const words = input.split('\n').filter(w => w.trim());
      setClusters([
        { topic: 'Informational', keywords: words.filter((_, i) => i % 2 === 0) },
        { topic: 'Transactional', keywords: words.filter((_, i) => i % 2 !== 0) },
      ]);
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="glass-panel p-6 rounded-xl h-full">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-white">
        <Search className="text-brand-500" /> Keyword Cluster Generator
      </h3>
      <div className="space-y-4">
        <textarea
          className="w-full bg-dark-800 border border-slate-700 rounded-lg p-3 text-sm focus:ring-2 focus:ring-brand-500 outline-none text-slate-200"
          rows={5}
          placeholder="Paste your keyword list here (one per line)..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button
          onClick={handleCluster}
          disabled={loading}
          className="bg-brand-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-brand-500 disabled:opacity-50 transition-all w-full"
        >
          {loading ? 'Analyzing Semantics...' : 'Generate Clusters'}
        </button>
      </div>
      {clusters.length > 0 && (
        <div className="mt-6 grid md:grid-cols-2 gap-4">
          {clusters.map((c, i) => (
            <div key={i} className="bg-dark-800 p-4 rounded-lg border border-slate-700">
              <h4 className="font-semibold text-brand-400 mb-2">{c.topic} Intent</h4>
              <ul className="text-sm text-slate-400 space-y-1">
                {c.keywords.map((k, j) => <li key={j}>• {k}</li>)}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export const LinkGraphTool: React.FC = () => {
    const svgRef = useRef<SVGSVGElement>(null);
  
    useEffect(() => {
      if (!svgRef.current) return;
  
      const width = svgRef.current.clientWidth;
      const height = 300;
  
      const nodes = Array.from({ length: 15 }, (_, i) => ({ id: i }));
      const links = Array.from({ length: 20 }, () => ({
        source: Math.floor(Math.random() * 15),
        target: Math.floor(Math.random() * 15),
      }));
  
      const simulation = d3.forceSimulation(nodes as any)
        .force("link", d3.forceLink(links).id((d: any) => d.id).distance(50))
        .force("charge", d3.forceManyBody().strength(-50))
        .force("center", d3.forceCenter(width / 2, height / 2));
  
      const svg = d3.select(svgRef.current);
      svg.selectAll("*").remove();
  
      const link = svg.append("g")
        .selectAll("line")
        .data(links)
        .join("line")
        .attr("stroke", "#475569")
        .attr("stroke-width", 1.5);
  
      const node = svg.append("g")
        .selectAll("circle")
        .data(nodes)
        .join("circle")
        .attr("r", 6)
        .attr("fill", "#0ea5e9");
  
      simulation.on("tick", () => {
        link
          .attr("x1", (d: any) => d.source.x)
          .attr("y1", (d: any) => d.source.y)
          .attr("x2", (d: any) => d.target.x)
          .attr("y2", (d: any) => d.target.y);
  
        node
          .attr("cx", (d: any) => d.x)
          .attr("cy", (d: any) => d.y);
      });
      
      return () => {
        simulation.stop();
      };
    }, []);
  
    return (
      <div className="glass-panel p-6 rounded-xl h-full">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-white">
          <Network className="text-brand-500" /> Internal Link Visualizer
        </h3>
        <div className="bg-dark-800 rounded-lg overflow-hidden border border-slate-700">
           <svg ref={svgRef} className="w-full h-[300px]"></svg>
        </div>
        <p className="text-xs text-slate-500 mt-2">
            *Visualizing orphan pages and click-depth distribution.
        </p>
      </div>
    );
};

export const SeoAuditSimulator: React.FC = () => {
  const [url, setUrl] = useState('');
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<any>(null);

  const handleScan = () => {
    if (!url) return;
    setScanning(true);
    setProgress(0);
    setResult(null);

    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setScanning(false);
          setResult({
            score: 78,
            issues: [
              { type: 'error', text: 'Missing Meta Description on 3 pages' },
              { type: 'warning', text: 'LCP is 3.2s (Needs Improvement)' },
              { type: 'success', text: 'SSL Certificate Valid' },
              { type: 'success', text: 'Mobile Friendly' },
            ]
          });
          return 100;
        }
        return prev + 2;
      });
    }, 50);
  };

  return (
    <div className="glass-panel p-6 rounded-xl h-full">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-white">
        <Cpu className="text-brand-500" /> SEO Site Audit Simulator
      </h3>
      <div className="flex gap-2 mb-4">
        <input 
          type="text" 
          placeholder="https://example.com" 
          className="flex-1 bg-dark-800 border border-slate-700 rounded-lg p-2 text-white focus:ring-2 focus:ring-brand-500 outline-none"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
        <button 
          onClick={handleScan}
          disabled={scanning}
          className="bg-brand-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-brand-500 disabled:opacity-50"
        >
          {scanning ? 'Scanning...' : 'Audit'}
        </button>
      </div>

      {scanning && (
        <div className="w-full bg-dark-800 rounded-full h-2.5 mb-4">
          <div className="bg-brand-500 h-2.5 rounded-full transition-all duration-75" style={{ width: `${progress}%` }}></div>
        </div>
      )}

      {result && (
        <div className="animate-fade-in">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-full border-4 border-yellow-500 flex items-center justify-center text-xl font-bold text-white">
              {result.score}
            </div>
            <div>
              <div className="text-sm text-slate-400">Overall Health Score</div>
              <div className="font-bold text-yellow-500">Good, needs work</div>
            </div>
          </div>
          <ul className="space-y-2">
            {result.issues.map((issue: any, i: number) => (
              <li key={i} className="flex items-center gap-2 text-sm">
                {issue.type === 'error' && <AlertTriangle size={16} className="text-red-500" />}
                {issue.type === 'warning' && <AlertTriangle size={16} className="text-yellow-500" />}
                {issue.type === 'success' && <CheckCircle size={16} className="text-green-500" />}
                <span className="text-slate-300">{issue.text}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export const ContentBriefGenerator: React.FC = () => {
  const [keyword, setKeyword] = useState('');
  const [brief, setBrief] = useState<any>(null);

  const generateBrief = () => {
    if (!keyword) return;
    setBrief({
      title: `Ultimate Guide to ${keyword}`,
      wordCount: '1,500 - 2,000 words',
      difficulty: 'Medium',
      outline: [
        'Introduction: Define what is ' + keyword,
        'Importance: Why ' + keyword + ' matters in 2024',
        'Strategy: Best practices for implementing ' + keyword,
        'Tools: Top software for ' + keyword,
        'Conclusion & Next Steps'
      ]
    });
  };

  return (
    <div className="glass-panel p-6 rounded-xl h-full">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-white">
        <FileText className="text-brand-500" /> Content Brief Generator
      </h3>
      <div className="flex gap-2 mb-6">
        <input 
          type="text" 
          placeholder="Target Keyword..." 
          className="flex-1 bg-dark-800 border border-slate-700 rounded-lg p-2 text-white focus:ring-2 focus:ring-brand-500 outline-none"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
        />
        <button 
          onClick={generateBrief}
          className="bg-brand-600 text-white px-4 py-2 rounded-lg font-bold hover:bg-brand-500"
        >
          Generate
        </button>
      </div>

      {brief && (
        <div className="bg-dark-800 p-4 rounded-lg border border-slate-700 animate-fade-in">
          <div className="flex justify-between items-start mb-4 border-b border-slate-700 pb-2">
            <h4 className="font-bold text-white">{brief.title}</h4>
            <span className="text-xs bg-brand-900 text-brand-300 px-2 py-1 rounded">{brief.difficulty}</span>
          </div>
          <div className="mb-3 text-xs text-slate-400">Target Length: <span className="text-white">{brief.wordCount}</span></div>
          <h5 className="font-semibold text-brand-400 text-sm mb-2">Suggested H2 Structure:</h5>
          <ul className="space-y-1">
            {brief.outline.map((item: string, i: number) => (
              <li key={i} className="text-sm text-slate-300 flex gap-2">
                <span className="text-slate-600">{i + 1}.</span> {item}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};