import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Menu, X, Linkedin, Mail, ChevronRight, Lock } from 'lucide-react';
import { NAV_LINKS } from '../constants';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <div className="min-h-screen flex flex-col font-sans text-slate-300 bg-dark-900 overflow-x-hidden">
      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'glass-panel py-3' : 'bg-transparent py-5'}`}>
        <div className="container mx-auto px-4 flex justify-between items-center">
          
          {/* Logo Section */}
          <NavLink to="/" className="flex flex-col group">
            <div className="text-xl md:text-2xl font-extrabold tracking-tighter text-white flex items-center gap-2">
              <span className="w-8 h-8 rounded bg-gradient-to-tr from-brand-600 to-brand-400 flex items-center justify-center text-white text-xs font-bold shadow-lg shadow-brand-500/30">SC</span>
              <span className="uppercase tracking-wide">SHRAVAN CHAUHAN</span>
            </div>
            <span className="text-[10px] md:text-xs text-brand-400 font-medium tracking-widest pl-10 hidden sm:block group-hover:text-accent-500 transition-colors">
              SEO Analyst & Digital Marketing Strategist
            </span>
          </NavLink>

          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center gap-6">
            {NAV_LINKS.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) =>
                  `text-sm font-medium transition-colors hover:text-brand-400 ${isActive ? 'text-brand-500' : 'text-slate-400'}`
                }
              >
                {link.name}
              </NavLink>
            ))}
            
            {/* Social Icons in Header */}
            <div className="h-6 w-px bg-slate-700 mx-2"></div>
            <a 
              href="https://www.linkedin.com/in/shravan-chauhan-3786a515a" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-slate-400 hover:text-[#0077b5] transition-colors"
              aria-label="LinkedIn"
            >
              <Linkedin size={20} />
            </a>

            <NavLink to="/contact" className="px-5 py-2 rounded bg-brand-600 text-white font-semibold hover:bg-brand-500 transition-colors shadow-lg shadow-brand-500/20 text-sm tracking-wide">
              Book Consultation
            </NavLink>
          </div>

          {/* Mobile Toggle */}
          <button className="lg:hidden text-white" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="absolute top-full left-0 w-full glass-panel border-b border-slate-700 py-4 px-4 flex flex-col gap-4 lg:hidden">
            {NAV_LINKS.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                className={({ isActive }) =>
                  `block py-2 text-base font-medium ${isActive ? 'text-brand-500' : 'text-slate-300'}`
                }
              >
                {link.name}
              </NavLink>
            ))}
            <a 
              href="https://www.linkedin.com/in/shravan-chauhan-3786a515a" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-slate-300 hover:text-brand-400 py-2"
            >
              <Linkedin size={18} /> LinkedIn Profile
            </a>
            <NavLink to="/contact" className="text-center py-3 bg-brand-600 text-white rounded font-bold uppercase text-sm tracking-wider">
              Book Consultation
            </NavLink>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="flex-grow pt-24">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-dark-900 border-t border-slate-800 pt-16 pb-8 mt-20 relative">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-4 text-white font-bold text-xl tracking-tight">
                 <div className="w-6 h-6 rounded bg-brand-600 flex items-center justify-center text-[10px]">SC</div>
                 SHRAVAN CHAUHAN
              </div>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">
                Data-Driven SEO, Measurable Growth, and High-Impact Digital Strategy. I help brands scale organically.
              </p>
              <div className="flex gap-4">
                <a 
                  href="https://www.linkedin.com/in/shravan-chauhan-3786a515a" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-[#0077b5] transition-all"
                  title="LinkedIn"
                >
                  <Linkedin size={18} />
                </a>
                <a href="mailto:shravan.chauhan0009@gmail.com" title="shravan.chauhan0009@gmail.com" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white hover:bg-brand-500 transition-all">
                  <Mail size={18} />
                </a>
              </div>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Services</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><NavLink to="/services" className="hover:text-brand-400 transition-colors">Technical Audits</NavLink></li>
                <li><NavLink to="/services" className="hover:text-brand-400 transition-colors">eCommerce SEO</NavLink></li>
                <li><NavLink to="/services" className="hover:text-brand-400 transition-colors">Content Strategy</NavLink></li>
                <li><NavLink to="/services" className="hover:text-brand-400 transition-colors">Local SEO</NavLink></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Resources</h4>
              <ul className="space-y-2 text-sm text-slate-400">
                <li><NavLink to="/blog" className="hover:text-brand-400 transition-colors">SEO Blog</NavLink></li>
                <li><NavLink to="/tools" className="hover:text-brand-400 transition-colors">Free SEO Tools</NavLink></li>
                <li><NavLink to="/case-studies" className="hover:text-brand-400 transition-colors">Case Studies</NavLink></li>
              </ul>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Get in Touch</h4>
              <div className="glass-panel p-5 rounded-xl border border-slate-700/50">
                <p className="text-xs text-slate-400 mb-3">Ready to grow your traffic?</p>
                <NavLink to="/contact" className="flex items-center justify-between text-brand-400 font-bold hover:text-accent-500 text-sm transition-colors group">
                  Book a Consultation <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform"/>
                </NavLink>
              </div>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 flex flex-col md:flex-row justify-between items-center text-xs text-slate-500">
            <p>© 2025 Shravan Chauhan. All rights reserved.</p>
            <div className="flex gap-6 mt-4 md:mt-0 items-center">
              <NavLink to="/admin" className="flex items-center gap-1 hover:text-brand-500"><Lock size={10}/> Admin</NavLink>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};