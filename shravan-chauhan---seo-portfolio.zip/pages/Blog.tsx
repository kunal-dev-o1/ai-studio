import React from 'react';
import { useStore } from '../services/store';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Clock, Calendar, Tag } from 'lucide-react';

const Blog: React.FC = () => {
    const { blogPosts } = useStore();
    const { id } = useParams<{ id: string }>();

    // Detail View
    if (id) {
        const post = blogPosts.find(p => p.id === id);
        
        if (!post) {
            return (
                <div className="container mx-auto px-4 py-20 text-center">
                    <h2 className="text-2xl text-white mb-4">Post not found</h2>
                    <Link to="/blog" className="text-brand-400 hover:text-brand-300">Return to Blog</Link>
                </div>
            );
        }

        return (
            <article className="container mx-auto px-4 pb-20 pt-10">
                <Link to="/blog" className="inline-flex items-center text-slate-400 hover:text-brand-400 mb-8 transition-colors">
                    <ArrowLeft size={16} className="mr-2" /> Back to Blog
                </Link>
                
                <div className="max-w-4xl mx-auto">
                    <div className="mb-8">
                        <div className="flex gap-4 text-xs font-medium text-brand-400 mb-4 uppercase tracking-wider">
                            <span className="flex items-center gap-1"><Tag size={12}/> {post.category}</span>
                            <span className="flex items-center gap-1"><Calendar size={12}/> {post.date}</span>
                            <span className="flex items-center gap-1"><Clock size={12}/> {post.readTime}</span>
                        </div>
                        <h1 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">{post.title}</h1>
                        <p className="text-xl text-slate-400 leading-relaxed border-l-4 border-brand-500 pl-4">{post.excerpt}</p>
                    </div>

                    <div className="rounded-2xl overflow-hidden mb-10 shadow-2xl shadow-black/50 border border-slate-700">
                        <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover max-h-[500px]" />
                    </div>

                    <div className="prose prose-invert prose-lg max-w-none text-slate-300">
                        <div dangerouslySetInnerHTML={{ __html: post.content || '' }} />
                    </div>
                    
                    <div className="mt-12 pt-8 border-t border-slate-800 flex justify-between items-center">
                        <div className="text-slate-500 italic">Written by Shravan Chauhan</div>
                        <div className="flex gap-2">
                             {/* Social Share mock */}
                             <div className="w-8 h-8 rounded-full bg-dark-800 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer transition-colors">in</div>
                             <div className="w-8 h-8 rounded-full bg-dark-800 border border-slate-700 flex items-center justify-center text-slate-400 hover:text-white cursor-pointer transition-colors">tw</div>
                        </div>
                    </div>
                </div>
            </article>
        );
    }

    // List View
    return (
        <div className="container mx-auto px-4 pb-20">
             <div className="max-w-3xl mb-12 mx-auto text-center pt-10">
                <h1 className="text-4xl font-bold text-white mb-4">SEO Insights & Thoughts</h1>
                <p className="text-xl text-slate-400">
                    Deep dives into technical SEO, content strategy, and the future of search.
                </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                {blogPosts.map(post => (
                    <article key={post.id} className="group bg-dark-800 rounded-xl overflow-hidden border border-slate-700 hover:border-brand-500/50 transition-all hover:-translate-y-1 flex flex-col h-full">
                        <div className="relative h-48 overflow-hidden">
                            <img src={post.imageUrl} alt={post.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                            <div className="absolute top-4 left-4 bg-brand-900/80 backdrop-blur text-brand-300 text-xs font-bold px-3 py-1 rounded-full border border-brand-500/30">
                                {post.category}
                            </div>
                        </div>
                        <div className="p-6 flex flex-col flex-grow">
                            <div className="flex items-center gap-4 text-xs text-slate-500 mb-3">
                                <span>{post.date}</span>
                                <span>•</span>
                                <span>{post.readTime}</span>
                            </div>
                            <h3 className="text-xl font-bold text-white mb-3 group-hover:text-brand-400 transition-colors">
                                {post.title}
                            </h3>
                            <p className="text-slate-400 text-sm leading-relaxed mb-4 flex-grow">
                                {post.excerpt}
                            </p>
                            <Link to={`/blog/${post.id}`} className="text-brand-400 text-sm font-medium hover:text-brand-300 inline-flex items-center mt-auto">
                                Read More <ArrowLeft size={14} className="ml-1 rotate-180" />
                            </Link>
                        </div>
                    </article>
                ))}
            </div>
        </div>
    );
};

export default Blog;