import React, { useState, useEffect } from 'react';
import { TrafficChart, AcquisitionChart, DeviceChart } from '../components/Charts';
import { ArrowUp, ArrowDown, Users, Clock, MousePointer, Globe } from 'lucide-react';

// Mock Data Generators
const generateTrafficData = () => Array.from({ length: 30 }, (_, i) => ({
    name: `Day ${i + 1}`,
    organic: Math.floor(Math.random() * 2000) + 3000,
    paid: Math.floor(Math.random() * 800) + 200,
}));

const DASHBOARD_METRICS = [
    { label: 'Total Users', value: '45,231', change: '+12.5%', isPos: true, icon: Users },
    { label: 'Avg. Session', value: '2m 45s', change: '+5.2%', isPos: true, icon: Clock },
    { label: 'Bounce Rate', value: '42.3%', change: '-2.1%', isPos: true, icon: MousePointer }, // Negative change is good here
    { label: 'Organic Share', value: '68%', change: '+4.5%', isPos: true, icon: Globe },
];

const Dashboard: React.FC = () => {
    const [data, setData] = useState(generateTrafficData());
    const [dateRange, setDateRange] = useState('Last 30 Days');

    // Simulate "Live" updates
    useEffect(() => {
        const interval = setInterval(() => {
            setData(prev => {
                // Correctly handle immutable state update
                const newData = [...prev];
                const lastIndex = newData.length - 1;
                
                if (lastIndex >= 0) {
                    const lastItem = { ...newData[lastIndex] };
                    // Slight jitter logic
                    const jitter = (Math.random() * 200) - 100;
                    lastItem.organic = Math.max(3000, Math.floor(lastItem.organic + jitter));
                    
                    newData[lastIndex] = lastItem;
                }
                return newData;
            });
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="container mx-auto px-4 pb-20">
            <div className="flex justify-between items-center mb-8 pt-10">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Live SEO Performance</h1>
                    <p className="text-slate-400">Simulated real-time analytics for a SaaS Client Project.</p>
                </div>
                <select 
                    value={dateRange}
                    onChange={(e) => setDateRange(e.target.value)}
                    className="bg-dark-800 border border-slate-700 text-white px-4 py-2 rounded-lg text-sm focus:outline-none focus:border-brand-500"
                >
                    <option>Last 7 Days</option>
                    <option>Last 30 Days</option>
                    <option>Last Quarter</option>
                </select>
            </div>

            {/* Top Metrics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                {DASHBOARD_METRICS.map((metric, i) => (
                    <div key={i} className="glass-panel p-6 rounded-xl border-t-2 border-t-brand-500">
                        <div className="flex justify-between items-start mb-4">
                            <div className="p-2 bg-brand-900/30 rounded-lg text-brand-400">
                                <metric.icon size={20} />
                            </div>
                            <span className={`text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1 ${metric.isPos ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'}`}>
                                {metric.isPos ? <ArrowUp size={12}/> : <ArrowDown size={12}/>}
                                {metric.change}
                            </span>
                        </div>
                        <div className="text-3xl font-bold text-white mb-1">{metric.value}</div>
                        <div className="text-xs text-slate-500">{metric.label}</div>
                    </div>
                ))}
            </div>

            {/* Main Charts Area */}
            <div className="grid lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 glass-panel p-6 rounded-xl min-h-[350px]">
                    <h3 className="text-lg font-bold text-white mb-6">Traffic Acquisition (Organic vs Paid)</h3>
                    <TrafficChart data={data} />
                </div>
                <div className="space-y-8">
                    <div className="glass-panel p-6 rounded-xl min-h-[300px]">
                        <h3 className="text-lg font-bold text-white mb-6">Top Acquisition Channels</h3>
                        <AcquisitionChart data={[
                            { name: 'Organic Search', value: 65 },
                            { name: 'Direct', value: 20 },
                            { name: 'Referral', value: 10 },
                            { name: 'Social', value: 5 },
                        ]} />
                    </div>
                    <div className="glass-panel p-6 rounded-xl min-h-[300px]">
                         <h3 className="text-lg font-bold text-white mb-6">Device Breakdown</h3>
                         <DeviceChart data={[
                             { name: 'Desktop', value: 55 },
                             { name: 'Mobile', value: 35 },
                             { name: 'Tablet', value: 10 },
                         ]} />
                    </div>
                </div>
            </div>
            
            <div className="mt-8 glass-panel p-6 rounded-xl">
                <h3 className="text-lg font-bold text-white mb-4">Top Performing Keywords</h3>
                <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm text-slate-400">
                        <thead className="bg-dark-800 text-slate-200 uppercase text-xs">
                            <tr>
                                <th className="p-3 rounded-l-lg">Keyword</th>
                                <th className="p-3">Position</th>
                                <th className="p-3">Vol</th>
                                <th className="p-3 rounded-r-lg">Traffic %</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800">
                            {[
                                { kw: 'enterprise seo services', pos: 3, vol: '1.2k', traffic: '12%' },
                                { kw: 'saas marketing agency', pos: 1, vol: '800', traffic: '8%' },
                                { kw: 'technical audit checklist', pos: 5, vol: '2.4k', traffic: '6%' },
                                { kw: 'cro best practices', pos: 2, vol: '500', traffic: '5%' },
                            ].map((row, idx) => (
                                <tr key={idx} className="hover:bg-dark-800/50 transition-colors">
                                    <td className="p-3 font-medium text-white">{row.kw}</td>
                                    <td className="p-3 text-brand-400 font-bold">#{row.pos}</td>
                                    <td className="p-3">{row.vol}</td>
                                    <td className="p-3">{row.traffic}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;