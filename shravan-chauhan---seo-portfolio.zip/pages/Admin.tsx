
import React, { useState } from 'react';
import { useStore } from '../services/store';
import { Trash2, Plus, FileText, Layout, Users, Settings, Activity, Check, X, RefreshCw, Mail } from 'lucide-react';
import { AppSettings, Lead } from '../types';

const Admin: React.FC = () => {
  const { caseStudies, blogPosts, leads, settings, logs, deleteCaseStudy, deleteBlogPost, updateLeadStatus, updateSettings, testSystem } = useStore();
  const [activeTab, setActiveTab] = useState<'posts' | 'cases' | 'leads' | 'settings' | 'logs'>('leads');
  const [localSettings, setLocalSettings] = useState<AppSettings>(settings);

  const handleSettingsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setLocalSettings(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
    }));
  };

  const saveSettings = (e: React.FormEvent) => {
      e.preventDefault();
      updateSettings(localSettings);
      alert('Settings Saved');
  };

  return (
    <div className="container mx-auto px-4 pb-20 pt-10">
      <div className="flex justify-between items-center mb-8">
        <div>
            <h1 className="text-3xl font-bold text-white">CMS Dashboard</h1>
            <div className="text-sm text-slate-400">Manage Content, Leads, and Integrations</div>
        </div>
        <div className="flex gap-4">
             <button onClick={testSystem} className="bg-dark-800 border border-slate-700 text-slate-300 px-4 py-2 rounded-lg text-sm hover:text-white hover:border-brand-500 transition-colors">
                Test Lead System
             </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-2">
          <button onClick={() => setActiveTab('leads')} className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${activeTab === 'leads' ? 'bg-brand-600 text-white' : 'text-slate-400 hover:bg-dark-800'}`}>
            <Users size={18} /> Leads <span className="ml-auto bg-brand-900 text-xs px-2 py-0.5 rounded-full">{leads.filter(l => l.status === 'New').length}</span>
          </button>
          <button onClick={() => setActiveTab('posts')} className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${activeTab === 'posts' ? 'bg-brand-600 text-white' : 'text-slate-400 hover:bg-dark-800'}`}>
            <FileText size={18} /> Blog Posts
          </button>
          <button onClick={() => setActiveTab('cases')} className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${activeTab === 'cases' ? 'bg-brand-600 text-white' : 'text-slate-400 hover:bg-dark-800'}`}>
            <Layout size={18} /> Case Studies
          </button>
          <div className="h-px bg-slate-800 my-2"></div>
          <button onClick={() => setActiveTab('settings')} className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${activeTab === 'settings' ? 'bg-brand-600 text-white' : 'text-slate-400 hover:bg-dark-800'}`}>
            <Settings size={18} /> Settings
          </button>
          <button onClick={() => setActiveTab('logs')} className={`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition-colors ${activeTab === 'logs' ? 'bg-brand-600 text-white' : 'text-slate-400 hover:bg-dark-800'}`}>
            <Activity size={18} /> Delivery Logs
          </button>
        </div>

        {/* Content Area */}
        <div className="lg:col-span-4">
          <div className="glass-panel rounded-xl overflow-hidden border border-slate-700 min-h-[600px]">
            
            {/* Leads Panel */}
            {activeTab === 'leads' && (
                <div className="flex flex-col h-full">
                    <div className="p-6 border-b border-slate-700 flex justify-between items-center bg-dark-800">
                        <h2 className="text-xl font-bold text-white">Inbound Leads</h2>
                        <button className="text-sm text-brand-400 hover:text-white">Export CSV</button>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm text-slate-400">
                            <thead className="bg-dark-900 text-xs uppercase text-slate-500">
                                <tr>
                                    <th className="p-4">Name / Date</th>
                                    <th className="p-4">Contact</th>
                                    <th className="p-4">Details</th>
                                    <th className="p-4">Status</th>
                                    <th className="p-4 text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-700">
                                {leads.map(lead => (
                                    <tr key={lead.id} className="hover:bg-dark-800/50">
                                        <td className="p-4">
                                            <div className="font-bold text-white">{lead.name}</div>
                                            <div className="text-xs">{lead.submittedAt}</div>
                                            {lead.source && <span className="text-[10px] bg-slate-800 px-1 rounded text-slate-400">{lead.source}</span>}
                                        </td>
                                        <td className="p-4">
                                            <div className="text-white">{lead.email}</div>
                                            <div className="text-xs">{lead.phone || '-'}</div>
                                            {lead.website && <a href={lead.website} target="_blank" className="text-xs text-brand-400 hover:underline truncate block max-w-[150px]">{lead.website}</a>}
                                        </td>
                                        <td className="p-4">
                                            <div className="line-clamp-2 text-xs mb-1 italic">"{lead.message}"</div>
                                            {lead.preferredTime && <div className="text-xs text-accent-500 font-semibold flex items-center gap-1"><RefreshCw size={10}/> Booking: {new Date(lead.preferredTime).toLocaleDateString()}</div>}
                                        </td>
                                        <td className="p-4">
                                            <span className={`px-2 py-1 rounded text-xs font-bold ${
                                                lead.status === 'New' ? 'bg-brand-600 text-white' :
                                                lead.status === 'Contacted' ? 'bg-green-600 text-white' :
                                                'bg-slate-700 text-slate-300'
                                            }`}>
                                                {lead.status}
                                            </span>
                                        </td>
                                        <td className="p-4 text-right space-x-2">
                                            <button onClick={() => updateLeadStatus(lead.id, 'Contacted')} className="p-1 hover:text-green-400" title="Mark Contacted"><Check size={16}/></button>
                                            <button onClick={() => updateLeadStatus(lead.id, 'Closed')} className="p-1 hover:text-red-400" title="Close"><X size={16}/></button>
                                        </td>
                                    </tr>
                                ))}
                                {leads.length === 0 && (
                                    <tr>
                                        <td colSpan={5} className="p-8 text-center text-slate-500">No leads found yet.</td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* Settings Panel */}
            {activeTab === 'settings' && (
                <form onSubmit={saveSettings} className="p-8 space-y-8">
                    <div>
                         <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2">System Mode</h3>
                         <div className="flex items-center gap-2 bg-dark-900 p-4 rounded border border-slate-700">
                            <input type="checkbox" id="testMode" name="testMode" checked={localSettings.testMode} onChange={handleSettingsChange} className="w-5 h-5 text-brand-600"/>
                            <div>
                                <label htmlFor="testMode" className="text-white font-bold block">Enable Test Mode</label>
                                <span className="text-xs text-slate-400">If Checked: No real emails are sent (simulated in logs). Uncheck to use live EmailJS.</span>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2">Notifications</h3>
                        <div className="grid md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-sm text-slate-400 mb-1">Notification Email</label>
                                <input name="notificationEmail" value={localSettings.notificationEmail} onChange={handleSettingsChange} className="w-full bg-dark-900 border border-slate-700 rounded p-2 text-white text-sm" />
                            </div>
                            <div>
                                <label className="block text-sm text-slate-400 mb-1">Notification Phone</label>
                                <input name="notificationPhone" value={localSettings.notificationPhone} onChange={handleSettingsChange} className="w-full bg-dark-900 border border-slate-700 rounded p-2 text-white text-sm" />
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2 flex items-center gap-2">
                             <Mail size={18} className="text-brand-500"/> Email Service Configuration (EmailJS)
                        </h3>
                        <div className="p-4 bg-brand-900/20 border border-brand-500/20 rounded mb-4 text-xs text-slate-300">
                            To receive real emails without a backend, sign up for <a href="https://www.emailjs.com/" target="_blank" className="text-brand-400 underline">EmailJS</a> (Free Tier), create a service & template, and paste keys below.
                        </div>
                        
                        <div className="flex items-center gap-2 mb-4">
                            <input type="checkbox" id="enableEmailJs" name="enableEmailJs" checked={localSettings.enableEmailJs} onChange={handleSettingsChange} />
                            <label htmlFor="enableEmailJs" className="text-white text-sm">Use EmailJS for Sending Emails</label>
                        </div>

                        <div className={`grid md:grid-cols-2 gap-6 ${!localSettings.enableEmailJs ? 'opacity-50 pointer-events-none' : ''}`}>
                            <div>
                                <label className="block text-sm text-slate-400 mb-1">Service ID</label>
                                <input name="emailJsServiceId" placeholder="service_xxxx" value={localSettings.emailJsServiceId} onChange={handleSettingsChange} className="w-full bg-dark-900 border border-slate-700 rounded p-2 text-white text-sm" />
                            </div>
                            <div>
                                <label className="block text-sm text-slate-400 mb-1">Template ID</label>
                                <input name="emailJsTemplateId" placeholder="template_xxxx" value={localSettings.emailJsTemplateId} onChange={handleSettingsChange} className="w-full bg-dark-900 border border-slate-700 rounded p-2 text-white text-sm" />
                            </div>
                             <div className="md:col-span-2">
                                <label className="block text-sm text-slate-400 mb-1">Public Key</label>
                                <input name="emailJsPublicKey" placeholder="User Public Key" value={localSettings.emailJsPublicKey} onChange={handleSettingsChange} className="w-full bg-dark-900 border border-slate-700 rounded p-2 text-white text-sm" />
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 className="text-lg font-bold text-white mb-4 border-b border-slate-700 pb-2">Twilio (SMS) - <span className="text-xs font-normal text-slate-500">Requires Backend</span></h3>
                        <div className="flex items-center gap-2 mb-4">
                            <input type="checkbox" id="enableTwilio" name="enableTwilio" checked={localSettings.enableTwilio} onChange={handleSettingsChange} />
                            <label htmlFor="enableTwilio" className="text-white text-sm">Enable SMS Notifications</label>
                        </div>
                        <div className="grid md:grid-cols-2 gap-6 opacity-50">
                            <div>
                                <label className="block text-sm text-slate-400 mb-1">Account SID</label>
                                <input name="twilioSid" value={localSettings.twilioSid} onChange={handleSettingsChange} className="w-full bg-dark-900 border border-slate-700 rounded p-2 text-white text-sm" disabled />
                            </div>
                            <div>
                                <label className="block text-sm text-slate-400 mb-1">Auth Token</label>
                                <input name="twilioAuthToken" value={localSettings.twilioAuthToken} onChange={handleSettingsChange} type="password" className="w-full bg-dark-900 border border-slate-700 rounded p-2 text-white text-sm" disabled/>
                            </div>
                        </div>
                    </div>

                    <div className="pt-4">
                        <button type="submit" className="bg-brand-600 hover:bg-brand-500 text-white px-6 py-2 rounded-lg font-bold transition-colors">Save Settings</button>
                    </div>
                </form>
            )}

            {/* Logs Panel */}
            {activeTab === 'logs' && (
                <div className="p-6">
                    <h2 className="text-xl font-bold text-white mb-6">System Delivery Logs</h2>
                    <div className="bg-dark-900 rounded-lg border border-slate-700 overflow-hidden font-mono text-xs">
                        {logs.map(log => (
                            <div key={log.id} className="p-3 border-b border-slate-800 flex gap-4 items-center hover:bg-slate-800/30">
                                <span className="text-slate-500 w-20">{log.timestamp}</span>
                                <span className={`px-2 py-0.5 rounded w-16 text-center ${log.status === 'Success' ? 'bg-green-900 text-green-400' : 'bg-red-900 text-red-400'}`}>{log.status}</span>
                                <span className="text-brand-400 w-16 font-bold">{log.type}</span>
                                <span className="text-slate-300">{log.message}</span>
                            </div>
                        ))}
                        {logs.length === 0 && <div className="p-4 text-center text-slate-500">No activity logged yet.</div>}
                    </div>
                </div>
            )}

            {/* Content Management Tabs (Simplified for brevity) */}
            {(activeTab === 'posts' || activeTab === 'cases') && (
                <div className="p-6">
                     <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold text-white">{activeTab === 'posts' ? 'Blog Posts' : 'Case Studies'}</h2>
                        <button className="bg-brand-600 hover:bg-brand-500 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2">
                            <Plus size={16} /> Add New
                        </button>
                    </div>
                    <div className="divide-y divide-slate-700">
                        {(activeTab === 'posts' ? blogPosts : caseStudies).map((item: any) => (
                            <div key={item.id} className="py-4 flex justify-between items-center hover:bg-dark-800 px-2 rounded transition-colors">
                                <div>
                                    <div className="font-semibold text-white">{item.title}</div>
                                    <div className="text-xs text-slate-500">{activeTab === 'posts' ? item.date : item.client}</div>
                                </div>
                                <button 
                                    onClick={() => activeTab === 'posts' ? deleteBlogPost(item.id) : deleteCaseStudy(item.id)}
                                    className="p-2 text-slate-400 hover:text-red-400 transition-colors"
                                >
                                    <Trash2 size={18} />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;