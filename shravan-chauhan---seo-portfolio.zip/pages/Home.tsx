import React from 'react';
import { ArrowRight, BarChart2, CheckCircle, Award } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { SERVICES, INITIAL_CASE_STUDIES } from '../constants';

const Home: React.FC = () => {
  return (
    <div className="flex flex-col gap-24 pb-20">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 px-4">
        {/* Background Elements */}
        <div className="absolute top-20 right-10 w-64 h-64 bg-brand-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
        <div className="absolute top-40 left-10 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>

        <div className="container mx-auto max-w-5xl text-center relative z-10">
          <div className="inline-block mb-4 px-4 py-1.5 rounded-full border border-brand-500/30 bg-brand-500/10 text-brand-400 text-sm font-semibold tracking-wide">
            4+ Years of Proven SEO Results
          </div>
          <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-6 leading-tight">
            Data-Driven SEO & <br />
            <span className="gradient-text">Digital Strategy That Delivers</span>
          </h1>
          <p className="text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            I’m Shravan Chauhan, an SEO Analyst & Digital Marketing Strategist with 4+ years of experience helping brands improve search visibility, boost conversions, and scale organic traffic sustainably.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <NavLink to="/contact" className="px-8 py-4 bg-brand-600 hover:bg-brand-500 text-white rounded-lg font-bold text-lg transition-all shadow-lg shadow-brand-500/25 flex items-center justify-center gap-2">
              Book a Consultation <ArrowRight size={20} />
            </NavLink>
          </div>

          {/* Metrics Banner */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {[
              { label: 'SEO Projects Delivered', value: '40+' },
              { label: 'Avg Organic Growth', value: '25-40%' },
              { label: 'Industry Niches', value: '10+' },
              { label: 'Experience', value: '4+ Years' },
            ].map((stat, i) => (
              <div key={i} className="glass-panel p-6 rounded-xl border-t border-brand-500/30">
                <div className="text-2xl md:text-3xl font-bold text-white mb-1">{stat.value}</div>
                <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">How I Drive Growth</h2>
          <p className="text-slate-400 max-w-xl mx-auto">My methodology blends technical precision with creative content strategy to dominate search results.</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {SERVICES.slice(0, 3).map((service) => (
            <div key={service.id} className="glass-panel p-8 rounded-2xl hover:border-brand-500/50 transition-colors group">
              <div className="w-12 h-12 bg-brand-900/50 rounded-lg flex items-center justify-center text-brand-400 mb-6 group-hover:scale-110 transition-transform">
                <BarChart2 />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">{service.title}</h3>
              <p className="text-slate-400 leading-relaxed mb-4">{service.description}</p>
            </div>
          ))}
        </div>
        <div className="text-center mt-10">
          <NavLink to="/services" className="inline-flex items-center text-brand-400 font-bold hover:text-brand-300">
            View All Services <ArrowRight size={16} className="ml-2" />
          </NavLink>
        </div>
      </section>

      {/* Featured Work */}
      <section className="container mx-auto px-4">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-2">Featured Case Studies</h2>
            <p className="text-slate-400">Real results from real campaigns.</p>
          </div>
          <NavLink to="/case-studies" className="hidden md:flex text-brand-400 font-medium items-center hover:text-brand-300">
            View All Work <ArrowRight size={16} className="ml-2" />
          </NavLink>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {INITIAL_CASE_STUDIES.slice(0, 3).map((study) => (
            <div key={study.id} className="group relative overflow-hidden rounded-2xl bg-dark-800 border border-slate-700 hover:border-brand-500/50 transition-all flex flex-col h-full">
              <div className="p-6 flex flex-col flex-grow">
                <div className="flex gap-2 mb-3">
                  <span className="text-xs font-bold text-brand-300 bg-brand-900/60 px-2 py-1 rounded backdrop-blur-sm">
                    {study.industry}
                  </span>
                </div>
                <h3 className="text-lg font-bold text-white mb-4 line-clamp-1">{study.title}</h3>
                <p className="text-sm text-slate-400 mb-6 flex-grow">{study.challenge}</p>
                
                <div className="grid grid-cols-2 gap-4 border-t border-slate-700 pt-4 mt-auto">
                    <div>
                      <div className="text-lg font-bold text-brand-400">{study.results[0].growth}</div>
                      <div className="text-xs text-slate-500">{study.results[0].metric}</div>
                    </div>
                    <div>
                      <div className="text-lg font-bold text-brand-400">{study.results[1].growth}</div>
                      <div className="text-xs text-slate-500">{study.results[1].metric}</div>
                    </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="container mx-auto px-4 mt-12">
        <div className="bg-gradient-to-r from-brand-900 to-dark-800 rounded-3xl p-12 text-center border border-brand-500/20 relative overflow-hidden">
          <div className="relative z-10">
            <h2 className="text-3xl font-bold text-white mb-6">Why Work With Me?</h2>
            <p className="text-slate-300 mb-8 max-w-xl mx-auto text-lg">
              Transparent, consistent, and growth-focused SEO that works in the real world. No vanity metrics—just results.
            </p>
            <NavLink to="/contact" className="inline-block bg-white text-brand-900 px-8 py-4 rounded-lg font-bold hover:bg-slate-100 transition-colors">
              Let's Work Together
            </NavLink>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;