import React from 'react';
import { KeywordClusterTool, LinkGraphTool, SeoAuditSimulator, ContentBriefGenerator } from '../components/SeoTools';

const Tools: React.FC = () => {
    return (
        <div className="container mx-auto px-4 pb-20">
            <div className="text-center mb-16 max-w-2xl mx-auto pt-10">
                <h1 className="text-4xl font-bold text-white mb-4">Free SEO Tools</h1>
                <p className="text-slate-400">
                    Handy utilities I built to automate parts of my workflow. Feel free to use them to simulate common SEO tasks.
                </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
                <SeoAuditSimulator />
                <ContentBriefGenerator />
                <KeywordClusterTool />
                <LinkGraphTool />
            </div>
        </div>
    );
};

export default Tools;