import React from 'react';
import { SERVICES } from '../constants';
import { NavLink } from 'react-router-dom';
import { ArrowRight, Search, FileText, PenTool, MapPin, ShoppingBag, TrendingUp, BarChart2, Calendar } from 'lucide-react';

const iconMap: Record<string, any> = {
  Search, FileText, PenTool, MapPin, ShoppingBag, TrendingUp, BarChart2, Calendar
};

const Services: React.FC = () => {
  return (
    <div className="container mx-auto px-4 pb-20">
      <div className="text-center max-w-3xl mx-auto mb-16 pt-10">
        <h1 className="text-4xl font-bold text-white mb-6">SEO & Digital Strategy Services</h1>
        <p className="text-xl text-slate-400">
          I provide end-to-end SEO solutions tailored to your business goals, from technical foundations to content-led growth.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 mb-20">
        {SERVICES.map((service) => {
          const Icon = iconMap[service.icon] || Search;
          return (
            <div key={service.id} className="glass-panel p-8 rounded-2xl border border-slate-700 hover:border-brand-500/50 transition-colors group">
              <div className="flex items-start gap-6">
                <div className="w-14 h-14 bg-brand-900/50 rounded-xl flex items-center justify-center text-brand-400 flex-shrink-0 group-hover:scale-110 transition-transform">
                  <Icon size={28} />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white mb-3">{service.title}</h3>
                  <p className="text-slate-400 leading-relaxed text-lg mb-4">{service.description}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-dark-800 rounded-3xl p-12 text-center border border-slate-700">
        <h2 className="text-3xl font-bold text-white mb-4">Not sure where to start?</h2>
        <p className="text-slate-400 mb-8 max-w-xl mx-auto">
          Every website is unique. Let's schedule a 15-minute discovery call to identify your biggest growth opportunities.
        </p>
        <NavLink to="/contact" className="inline-flex items-center bg-brand-600 hover:bg-brand-500 text-white px-8 py-4 rounded-lg font-bold transition-colors">
          Book a Free Discovery Call <ArrowRight size={20} className="ml-2"/>
        </NavLink>
      </div>
    </div>
  );
};

export default Services;