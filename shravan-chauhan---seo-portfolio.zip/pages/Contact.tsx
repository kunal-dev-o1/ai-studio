
import React, { useState } from 'react';
import { Mail, Calendar, CheckCircle, Send, Linkedin, FileText, ArrowRight, Download } from 'lucide-react';
import { useStore } from '../services/store';
import { NavLink } from 'react-router-dom';

const Contact: React.FC = () => {
    const { addLead } = useStore();
    const [step, setStep] = useState(1);
    const [submitting, setSubmitting] = useState(false);
    
    // Form State
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        phone: '',
        website: '',
        message: '',
        preferredTime: '',
        consent: false
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleCheckbox = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({ ...prev, consent: e.target.checked }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.consent) {
            alert("Please accept the privacy terms to continue.");
            return;
        }

        setSubmitting(true);
        await addLead(formData);
        setSubmitting(false);
        setStep(2);
    };

    return (
        <div className="container mx-auto px-4 pb-20 pt-10">
            <div className="max-w-6xl mx-auto bg-dark-800 rounded-3xl overflow-hidden border border-slate-700 shadow-2xl flex flex-col md:flex-row min-h-[600px]">
                
                {/* Info Panel */}
                <div className="md:w-1/3 bg-brand-900 p-8 md:p-12 relative overflow-hidden flex flex-col justify-between">
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-brand-600 to-transparent opacity-20 pointer-events-none"></div>
                    <div className="relative z-10">
                        <h2 className="text-2xl font-bold text-white mb-6">Let's Grow Your Business with Smart SEO</h2>
                        <p className="text-brand-100 mb-8 leading-relaxed">
                            I'm Shravan Chauhan, SEO Analyst & Digital Marketing Strategist with 4+ years of experience. Need an audit? Want traffic growth? Looking for monthly SEO support? Let's connect.
                        </p>
                        
                        <div className="space-y-6">
                             <div className="flex items-start gap-4">
                                <div className="bg-brand-800 p-2 rounded-lg"><Mail className="text-brand-300" size={20}/></div>
                                <div>
                                    <div className="text-white font-medium">Email Me</div>
                                    <a href="mailto:shravan.chauhan0009@gmail.com" className="text-brand-200 text-sm hover:text-white transition-colors">shravan.chauhan0009@gmail.com</a>
                                </div>
                             </div>
                             <div className="flex items-start gap-4">
                                <div className="bg-brand-800 p-2 rounded-lg"><Calendar className="text-brand-300" size={20}/></div>
                                <div>
                                    <div className="text-white font-medium">Book a Strategy Call</div>
                                    <div className="text-brand-200 text-sm">15-Minute Intro (Free)</div>
                                </div>
                             </div>
                             <div className="flex items-start gap-4">
                                <div className="bg-brand-800 p-2 rounded-lg"><Linkedin className="text-brand-300" size={20}/></div>
                                <div>
                                    <div className="text-white font-medium">LinkedIn</div>
                                    <a 
                                        href="https://www.linkedin.com/in/shravan-chauhan-3786a515a" 
                                        target="_blank" 
                                        rel="noopener noreferrer"
                                        className="text-brand-200 text-sm hover:text-white transition-colors"
                                    >
                                        /in/shravan-chauhan
                                    </a>
                                </div>
                             </div>
                        </div>
                    </div>
                    <div className="relative z-10 mt-12">
                        <div className="p-4 bg-brand-800/50 rounded-lg border border-brand-500/20">
                            <p className="text-xs text-brand-200 italic">"Shravan helped us scale from 0 to 45k organic visitors in just 6 months. Highly recommended."</p>
                        </div>
                    </div>
                </div>

                {/* Form Panel */}
                <div className="md:w-2/3 p-8 md:p-12 bg-dark-800 relative">
                    {step === 1 ? (
                        <form onSubmit={handleSubmit} className="space-y-6 animate-fade-in">
                            <div>
                                <h2 className="text-2xl font-bold text-white mb-1">Send a Message</h2>
                                <p className="text-slate-400 text-sm">Fill out the form below and I'll get back to you within 24 hours.</p>
                            </div>

                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-slate-400 mb-2">Name *</label>
                                    <input 
                                        name="name"
                                        required 
                                        type="text" 
                                        value={formData.name}
                                        onChange={handleChange}
                                        className="w-full bg-dark-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 outline-none transition-all" 
                                        placeholder="John Doe"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-400 mb-2">Email *</label>
                                    <input 
                                        name="email"
                                        required 
                                        type="email" 
                                        value={formData.email}
                                        onChange={handleChange}
                                        className="w-full bg-dark-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 outline-none transition-all" 
                                        placeholder="john@company.com"
                                    />
                                </div>
                            </div>

                            <div className="grid md:grid-cols-2 gap-6">
                                <div>
                                    <label className="block text-sm font-medium text-slate-400 mb-2">Phone (Optional)</label>
                                    <input 
                                        name="phone"
                                        type="tel" 
                                        value={formData.phone}
                                        onChange={handleChange}
                                        className="w-full bg-dark-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 outline-none transition-all" 
                                        placeholder="+1 (555) 000-0000"
                                    />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-slate-400 mb-2">Website URL</label>
                                    <input 
                                        name="website"
                                        type="url" 
                                        value={formData.website}
                                        onChange={handleChange}
                                        className="w-full bg-dark-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 outline-none transition-all" 
                                        placeholder="https://yourwebsite.com"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-slate-400 mb-2">Preferred Time for Call (Optional)</label>
                                <input 
                                    name="preferredTime"
                                    type="datetime-local" 
                                    value={formData.preferredTime}
                                    onChange={handleChange}
                                    className="w-full bg-dark-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 outline-none transition-all" 
                                />
                            </div>

                            <div>
                                <label className="block text-sm font-medium text-slate-400 mb-2">Message *</label>
                                <textarea 
                                    name="message"
                                    required
                                    rows={4} 
                                    value={formData.message}
                                    onChange={handleChange}
                                    className="w-full bg-dark-900 border border-slate-700 rounded-lg p-3 text-white focus:ring-2 focus:ring-brand-500 outline-none transition-all" 
                                    placeholder="Tell me about your project, goals, or current SEO challenges..."
                                ></textarea>
                            </div>

                            <div className="flex items-start gap-3 pt-2">
                                <input 
                                    type="checkbox" 
                                    id="consent" 
                                    checked={formData.consent}
                                    onChange={handleCheckbox}
                                    className="mt-1 w-4 h-4 rounded border-slate-700 bg-dark-900 text-brand-600 focus:ring-brand-500"
                                />
                                <label htmlFor="consent" className="text-xs text-slate-500">
                                    By submitting this form, you agree to receive emails regarding your inquiry. Your data is secure and you can unsubscribe anytime. View <a href="#" className="text-brand-400 hover:underline">Privacy Policy</a>.
                                </label>
                            </div>

                            <button 
                                type="submit" 
                                disabled={!formData.consent || submitting}
                                className="w-full bg-brand-600 hover:bg-brand-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-lg flex items-center justify-center gap-2 transition-all shadow-lg shadow-brand-500/20"
                            >
                                {submitting ? 'Sending...' : 'Send Message'} <Send size={18}/>
                            </button>
                        </form>
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-center py-12 animate-fade-in">
                            <div className="w-24 h-24 bg-green-500/10 rounded-full flex items-center justify-center text-green-500 mb-6 border border-green-500/20">
                                <CheckCircle size={48} />
                            </div>
                            <h3 className="text-3xl font-bold text-white mb-3">Message Sent!</h3>
                            <p className="text-slate-300 max-w-md mx-auto mb-8 text-lg">
                                Thanks {formData.name}, I’ve received your inquiry. I’ll review your details and get back to you within 48 hours.
                            </p>
                            
                            <div className="w-full max-w-sm space-y-3">
                                <button className="w-full flex items-center justify-center gap-2 bg-dark-900 border border-slate-700 hover:border-brand-500 text-white py-3 rounded-lg transition-all group">
                                    <Download size={18} className="text-brand-400 group-hover:translate-y-1 transition-transform"/> Download Intro PDF
                                </button>
                                
                                <NavLink to="/case-studies" className="w-full flex items-center justify-center gap-2 bg-brand-600 hover:bg-brand-500 text-white py-3 rounded-lg transition-all font-semibold">
                                    View Case Studies <ArrowRight size={18} />
                                </NavLink>
                            </div>

                            <div className="mt-8 pt-8 border-t border-slate-700/50">
                                <p className="text-sm text-slate-500 mb-2">Connect with me directly:</p>
                                <a 
                                    href="https://www.linkedin.com/in/shravan-chauhan-3786a515a" 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="inline-flex items-center gap-2 text-[#0077b5] hover:text-[#005885] font-semibold"
                                >
                                    <Linkedin size={20} /> LinkedIn Profile
                                </a>
                            </div>

                            <button onClick={() => setStep(1)} className="mt-8 text-sm text-slate-500 hover:text-white underline">
                                Send another message
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Contact;
