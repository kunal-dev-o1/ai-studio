import React from 'react';
import { useStore } from '../services/store';

const CaseStudies: React.FC = () => {
  const { caseStudies } = useStore();

  return (
    <div className="container mx-auto px-4 pb-20">
      <div className="max-w-3xl mb-12 pt-10">
        <h1 className="text-4xl font-bold text-white mb-4">Case Studies</h1>
        <p className="text-xl text-slate-400">
          Deep dives into how I've solved complex SEO challenges and driven revenue growth for diverse clients.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        {caseStudies.map((study) => (
          <div key={study.id} className="bg-dark-800 rounded-2xl p-8 border border-slate-700 hover:border-brand-500/50 transition-all flex flex-col h-full relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-brand-500/5 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
            
            <div className="flex items-center gap-3 mb-6 relative z-10">
                 <span className="text-brand-400 font-bold tracking-wider text-sm uppercase px-3 py-1 bg-brand-900/30 rounded border border-brand-500/20">{study.industry}</span>
                 <span className="w-1 h-1 bg-slate-500 rounded-full"></span>
                 <span className="text-slate-500 text-sm">{study.client}</span>
            </div>
            
            <h2 className="text-2xl font-bold text-white mb-6 leading-tight">{study.title}</h2>
            
            <div className="space-y-6 mb-8 flex-grow">
              <div className="p-4 bg-dark-900/50 rounded-lg border border-slate-800">
                <h4 className="text-slate-200 font-semibold mb-2 text-sm uppercase tracking-wide">The Challenge</h4>
                <p className="text-slate-400 leading-relaxed text-sm">{study.challenge}</p>
              </div>
              <div>
                <h4 className="text-brand-300 font-semibold mb-2 text-sm uppercase tracking-wide">The Solution</h4>
                <p className="text-slate-300 leading-relaxed text-sm">{study.solution}</p>
              </div>
            </div>

            {/* Results Grid */}
            <div className="grid grid-cols-3 gap-4 border-t border-slate-700 pt-6 mt-auto">
              {study.results.map((res, i) => (
                <div key={i}>
                  <div className="text-xl md:text-2xl font-bold text-brand-400 mb-1">{res.growth}</div>
                  <div className="text-[10px] md:text-xs text-slate-500 font-medium uppercase tracking-wide">{res.metric}</div>
                </div>
              ))}
            </div>
            
            <div className="mt-6 pt-4 flex flex-wrap gap-2">
                {study.tags.map((tag, i) => (
                    <span key={i} className="text-[10px] text-slate-500 bg-dark-900 px-2 py-1 rounded border border-slate-800">#{tag}</span>
                ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CaseStudies;