import React from 'react';
import { NavLink } from 'react-router-dom';
import { Target, Search, BarChart, Rocket, Linkedin } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="container mx-auto px-4 pb-20">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16 pt-10">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">About Me</h1>
          <p className="text-xl text-slate-400 leading-relaxed max-w-2xl mx-auto">
            I’m Shravan Chauhan, an SEO Analyst & Digital Marketer with 4+ years of hands-on experience helping businesses grow organically through technical accuracy, strategic content planning, and continuous optimization.
          </p>
        </div>

        {/* Profile Card */}
        <div className="glass-panel p-8 rounded-2xl mb-16 flex flex-col md:flex-row gap-8 items-center border border-slate-700">
           <div className="w-32 h-32 md:w-48 md:h-48 bg-gradient-to-br from-brand-500 to-brand-800 rounded-full flex-shrink-0 border-4 border-dark-900 shadow-xl flex items-center justify-center text-4xl font-bold text-white/20">
             SC
           </div>
           <div>
             <h2 className="text-2xl font-bold text-white mb-2">Shravan Chauhan</h2>
             <div className="text-brand-400 font-medium mb-4">SEO Analyst & Digital Marketing Strategist</div>
             <p className="text-slate-300 mb-6 leading-relaxed">
               I specialize in deciphering complex search algorithms and translating them into actionable revenue strategies. From small local businesses to large e-commerce stores, I don't just chase traffic—I chase growth that impacts your bottom line.
             </p>
             <div className="flex flex-wrap gap-2 mb-6">
               {['Technical SEO', 'On-Page SEO', 'Content Strategy', 'Local SEO', 'eCommerce SEO', 'CRO', 'Analytics'].map(skill => (
                 <span key={skill} className="px-3 py-1 bg-dark-900 rounded-full text-xs font-semibold text-slate-300 border border-slate-700">
                   {skill}
                 </span>
               ))}
             </div>
             
             <a 
               href="https://www.linkedin.com/in/shravan-chauhan-3786a515a"
               target="_blank"
               rel="noopener noreferrer"
               className="inline-flex items-center gap-2 text-[#0077b5] hover:text-[#005885] font-semibold transition-colors"
             >
               <Linkedin size={20} /> Connect on LinkedIn
             </a>
           </div>
        </div>

        {/* Process Section */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-white text-center mb-12">My Step-by-Step Approach</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-dark-800 p-8 rounded-xl border border-slate-700 relative overflow-hidden group hover:border-brand-500/50 transition-colors">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Search size={100} />
              </div>
              <div className="text-brand-500 mb-4"><Search size={32} /></div>
              <h3 className="text-xl font-bold text-white mb-2">1. Audit & Discovery</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                I start with a comprehensive technical and content audit to identify growth blockers, crawling issues, and low-hanging fruit.
              </p>
            </div>

            <div className="bg-dark-800 p-8 rounded-xl border border-slate-700 relative overflow-hidden group hover:border-brand-500/50 transition-colors">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Target size={100} />
              </div>
              <div className="text-brand-500 mb-4"><Target size={32} /></div>
              <h3 className="text-xl font-bold text-white mb-2">2. Strategy & Roadmap</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Based on data, I build a 6-12 month roadmap focusing on high-impact keywords, content clustering, and technical fixes.
              </p>
            </div>

            <div className="bg-dark-800 p-8 rounded-xl border border-slate-700 relative overflow-hidden group hover:border-brand-500/50 transition-colors">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <Rocket size={100} />
              </div>
              <div className="text-brand-500 mb-4"><Rocket size={32} /></div>
              <h3 className="text-xl font-bold text-white mb-2">3. Execution</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Implementation of on-page optimizations, content creation, link building, and technical schema deployment.
              </p>
            </div>

            <div className="bg-dark-800 p-8 rounded-xl border border-slate-700 relative overflow-hidden group hover:border-brand-500/50 transition-colors">
              <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
                <BarChart size={100} />
              </div>
              <div className="text-brand-500 mb-4"><BarChart size={32} /></div>
              <h3 className="text-xl font-bold text-white mb-2">4. Measure & Scale</h3>
              <p className="text-slate-400 text-sm leading-relaxed">
                Continuous monitoring via GA4 and Search Console to refine strategies and double down on what works.
              </p>
            </div>
          </div>
        </div>

        {/* Tools Section */}
        <div className="text-center mb-16">
           <h3 className="text-xl font-bold text-white mb-6">Tools I Use Daily</h3>
           <div className="flex flex-wrap justify-center gap-4 text-slate-400 text-sm font-medium">
             {['GA4', 'Search Console', 'Ahrefs', 'SEMrush', 'Screaming Frog', 'SurferSEO', 'Looker Studio', 'Shopify', 'WordPress'].map(tool => (
               <span key={tool} className="px-4 py-2 bg-dark-800 rounded border border-slate-700">{tool}</span>
             ))}
           </div>
        </div>

        <div className="flex justify-center gap-6">
          <NavLink to="/contact" className="px-8 py-3 bg-dark-800 hover:bg-dark-700 text-white border border-slate-700 rounded-lg font-bold transition-colors">
            Contact Me
          </NavLink>
        </div>
      </div>
    </div>
  );
};

export default About;